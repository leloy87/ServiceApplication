﻿using System.Collections.Generic;
using System.Windows.Forms;
using System;


namespace ServiceApplication
{
    public partial class ReportIssues : Form
    {
        // List to store the file paths of the selected files
        private List<string> selectedFiles = new List<string>();

        public ReportIssues()
        {
            InitializeComponent();
        }

        // Event handler for when the attachment label is clicked
        private void lblAttachment_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Attachment label clicked. You can now change the attached file if needed.");
        }

        // Logic to attach multiple media files
        private void btnAttachMedia_Click(object sender, EventArgs e)
        {
            // Open file dialog for the user to select media files
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Image Files|*.jpg;*.jpeg;*.png|Document Files|*.pdf;*.docx",
                Multiselect = true  // Allow multiple files to be selected
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Clear previously selected files
                selectedFiles.Clear();

                // Add selected file paths to the list
                selectedFiles.AddRange(openFileDialog.FileNames);

                // Display the selected file names in the label (without the full path)
                lblAttachment.Text = string.Join(", ", openFileDialog.SafeFileNames);
            }
        }

        // Logic to submit an issue
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            // Call the SubmitIssue method to handle submission
            SubmitIssue();
        }

        // Method to submit an issue
        private void SubmitIssue()
        {
            // Validate user input
            string location = txtLocation.Text.Trim();
            string category = cmbCategory.SelectedItem?.ToString();
            string description = rtxtDescription.Text.Trim();

            // Ensure required fields are filled out
            if (string.IsNullOrEmpty(location) || string.IsNullOrEmpty(category) || string.IsNullOrEmpty(description))
            {
                MessageBox.Show("Please fill out all required fields.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Create a new issue with the user's input
            var issue = new Issue
            {
                Location = location,
                Category = category,
                Description = description,
                Attachments = new List<string>(selectedFiles) // Add selected files if any
            };

            // Add the issue to the in-memory storage
            IssueStorage.Issues.Add(issue);

            // Show a success message
            MessageBox.Show("Issue submitted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Clear the form fields for new input
            txtLocation.Clear();
            cmbCategory.SelectedIndex = -1;
            rtxtDescription.Clear();
            lblAttachment.Text = "No files selected";
            selectedFiles.Clear();  // Clear the selected files list for next submission
        }

        // Logic to navigate back to the main menu
        private void btnBack_Click(object sender, EventArgs e)
        {
            // Create a new instance of the MainMenu form and show it
            MainMenu mainMenu = new MainMenu();
            mainMenu.Show();

            // Hide the current ReportIssues form
            this.Hide();
        }

        // Optional: Handle other events if needed
        private void Location_Click(object sender, EventArgs e)
        {
            // Optional: Handle Location label click
        }

        private void txtLocation_TextChanged(object sender, EventArgs e)
        {
            // Optional: Handle location text change
        }

        private void Category_Click(object sender, EventArgs e)
        {
            // Optional: Handle Category label click
        }

        private void cmbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Optional: Handle category selection change
        }

        private void Description_Click(object sender, EventArgs e)
        {
            // Optional: Handle Description label click
        }

        private void rtxtDescription_TextChanged(object sender, EventArgs e)
        {
            // Optional: Handle description text change
        }

       
           private void btnViewIssues_Click(object sender, EventArgs e)
            {
                // Create a new instance of the ViewIssues form
                ViewIssues viewIssuesForm = new ViewIssues();

                // Display the ViewIssues form
                viewIssuesForm.Show();
            }


        }
    }


