﻿using System;
using System.Windows.Forms;

namespace ServiceApplication
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        // Event handler for the Report Issues button
        private void ReportIssues(object sender, EventArgs e)
        {
            // Create an instance of the ReportIssues form
            ReportIssues reportIssuesForm = new ReportIssues();

            // Show the ReportIssues form
            reportIssuesForm.Show();

            // Optionally hide the Main Menu if you don't want both forms visible
            this.Hide();
        }

        private void LocalEvents(object sender, EventArgs e)
        {
            // Handle Local Events button click (if needed)
        }

        private void Service_Status(object sender, EventArgs e)
        {
            // Handle Service Status button click (if needed)
        }
    }
}
