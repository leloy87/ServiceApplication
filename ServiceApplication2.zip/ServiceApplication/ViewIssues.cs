﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace ServiceApplication
{
    public partial class ViewIssues : Form
    {
        private List<Issue> issues; // Declare class-level variable

        public ViewIssues()
        {
            InitializeComponent();
        }

        private void ViewIssues_Load(object sender, EventArgs e)
        {
            LoadIssues();
        }

        private void LoadIssues()
        {
            // Initialize the issues list from the IssueStorage class
            issues = IssueStorage.Issues;
            UpdateDataGridView(issues);
        }

        private void UpdateDataGridView(List<Issue> issuesToDisplay)
        {
            dataGridViewIssues.DataSource = null; // Clear existing data
            dataGridViewIssues.DataSource = issuesToDisplay; // Bind new data
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            string searchTerm = textBoxSearch.Text.ToLower();
            var filteredIssues = issues.Where(issue =>
                issue.Description.ToLower().Contains(searchTerm) ||
                issue.Id.ToString().Contains(searchTerm)).ToList();
            UpdateDataGridView(filteredIssues);
        }

        private void dataGridViewIssues_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Your logic here to handle cell clicks
        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            // Optionally handle text changes for real-time filtering
        }
    }


    // Define the Issue class
    public class Issue
    {
        public int Id { get; set; } // Added Id property
        public string Location { get; set; }
        public string Category { get; set; }
        public string Description { get; set; }
        public List<string> Attachments { get; set; } = new List<string>();
    }

    // In the MainMenu or ReportIssues form, store submitted issues in a list
    public static class IssueStorage
    {
        public static List<Issue> Issues = new List<Issue>();
    }
}
